#!/bin/sh
export FLASK_DEBUG=1
python3 wsgi.py
