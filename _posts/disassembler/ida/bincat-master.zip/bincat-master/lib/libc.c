int printf(const char *format, ...) {}
int sprintf(char *str, const char *format, ...) {}
int __printf_chk(int flag, const char * format, ...) {}
int __sprintf_chk(char * str, int flag, int strlen, const char * format, ...) {}
void *memcpy(void *dest, const void *src, unsigned int n) {}
unsigned int strlen(const char *s) {}
int puts(const char *s) {}
void *malloc(unsigned int) {} 
void free(void *) {}
