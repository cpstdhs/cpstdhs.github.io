let version = "1.7";;
let newspeak_hash = "git-c97fd380";;
