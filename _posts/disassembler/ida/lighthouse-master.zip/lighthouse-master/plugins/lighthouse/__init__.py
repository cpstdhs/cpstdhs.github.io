get_context = lambda x: None
