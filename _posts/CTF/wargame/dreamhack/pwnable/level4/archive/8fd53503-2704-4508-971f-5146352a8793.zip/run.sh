#!/bin/bash
LD_PRELOAD=/home/$user/libdlmalloc.so /home/$user/vuln
