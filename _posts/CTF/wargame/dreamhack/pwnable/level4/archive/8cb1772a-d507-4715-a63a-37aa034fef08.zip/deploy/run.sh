#!/bin/bash
#
cd /home/dream_restaurant
exec 2>/dev/null
timeout 20 /home/dream_restaurant/dream_restaurant
