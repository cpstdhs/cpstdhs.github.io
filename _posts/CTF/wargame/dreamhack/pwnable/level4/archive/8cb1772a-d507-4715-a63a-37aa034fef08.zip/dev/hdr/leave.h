/* leave.h
 */
#ifndef _LEAVE_H_
#define _LEAVE_H_

#define MAX_REVIEW_SIZE 128

void LeaveReview();
void LeaveReviewForRiceMenu();
void LeaveReviewForNoodleMenu();

#endif
