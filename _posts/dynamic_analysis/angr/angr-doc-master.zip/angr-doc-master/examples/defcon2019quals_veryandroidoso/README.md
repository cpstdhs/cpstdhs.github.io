For more details read: <http://antoniobianchi.me/posts/ctf-defconquals2019-veryandroidoso>.

