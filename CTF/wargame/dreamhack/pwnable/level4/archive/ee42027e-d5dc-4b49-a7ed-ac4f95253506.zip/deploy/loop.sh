#!/bin/bash

while :
do
	/home/chatbot/run.sh
	sleep 0.05
done
